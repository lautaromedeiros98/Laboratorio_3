function Funcion(numero) {
    if ((numero % 2) == 0) {
        return "El numero " + numero + " es par";
    }
    else {
        return "El numero " + numero + " es impar";
    }
}
console.log(Funcion(8));
console.log(Funcion(5));
