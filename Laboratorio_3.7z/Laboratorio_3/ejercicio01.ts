var msj1:string ="HOLA MUNDO!!!";
var msj2:string ='Puedo msotrar comillas `simples`';
var msj3:string =` y comillas "dobles"`;
console.log(msj1 +"\n"+ msj2 +"\n"+ msj3);
