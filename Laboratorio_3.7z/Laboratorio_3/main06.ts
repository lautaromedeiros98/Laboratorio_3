console.log(Informar(Cubo(6)));
