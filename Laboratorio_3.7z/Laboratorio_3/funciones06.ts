function Cubo(numero:number) : number
{
  return Math.pow(numero,3);
}

function Informar(numero:number) :string
{
  return"Numero: "+numero;
}
