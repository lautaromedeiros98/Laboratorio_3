"use strict";
var msj1 = "HOLA MUNDO!!!";
var msj2 = 'Puedo msotrar comillas `simples`';
var msj3 = " y comillas \"dobles\"";
console.log(msj1 + "\n" + msj2 + "\n" + msj3);
//# sourceMappingURL=ejercicio01.js.map