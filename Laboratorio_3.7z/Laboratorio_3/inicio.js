"use strict";
var nombre = "Lautaro";
var apellido = "Medeiros";
console.log(nombre + " " + apellido);
//# sourceMappingURL=inicio.js.map