console.log(Informar(Cubo(2)));
function Cubo(numero) {
    return Math.pow(numero, 3);
}
function Informar(numero) {
    return "Numero: " + numero;
}
