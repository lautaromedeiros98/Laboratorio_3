var nombre:string="Lautaro";
var apellido:string="Medeiros";
console.log(nombre+" "+apellido);
